//By Milk Can LLC
//https://github.com/milkcan

(function () {
  'use strict';

  angular.module('ionic-numberpicker', ['ionic','ionic-numberpicker.templates'])

})();